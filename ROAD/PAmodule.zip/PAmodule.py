import torch
import torch.nn as nn
from torch.nn import init
import functools
from torch.autograd import Variable
import numpy as np
import cv2
import time
import os
import matplotlib.pyplot as plt


class PAModule_Proj_1(nn.Module):
    # input image size is 14*14
    def __init__(self, in_channels, out_channels, size1=(16,16)):
        super(PAModule_Proj_1, self).__init__()
#        self.conv1 = nn.Conv2d(in_channels, out_channels//2, 1, 1, bias = False)#        
        self.first_residual_blocks = ResidualBlock(in_channels, out_channels)
        self.value_branches = nn.Sequential( #10
           nn.Conv2d(in_channels, 1,kernel_size=9, stride=2, padding=4, bias = False),
           nn.BatchNorm2d(1),
           nn.ReLU(inplace=True),
           nn.Conv2d(1, 1,kernel_size=7, stride=1, padding=3, bias = False),
           nn.BatchNorm2d(1),
           nn.ReLU(inplace=True),
         )
        self.value_branches2 =nn.Conv2d(1, out_channels,kernel_size=5, stride=1, padding=2, bias = False)
        self.mpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)    
        self.key_branches = nn.Sequential(
#            nn.BatchNorm2d(out_channels),
#            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=4, padding=0, bias=False),
            nn.Sigmoid()
        )
        self.last_blocks = ResidualBlock(in_channels, out_channels) 
 
    def forward(self, x):
#        x = self.first_residual_blocks(x)
#        print(x.shape)
        out_branch = self.value_branches(x)
#        print('PAModule_Proj_1.shape=',out_branch.shape,x.shape)
#        print('drawfeature...')
#        draw_features(out_branch.shape[0],out_branch.shape[1], out_branch.detach().cpu().numpy(), "HeatMap/1.png")
        out_branch=self.value_branches2(out_branch)
        out_branch = self.mpool1(out_branch)
#        print(out_branch.shape,x.shape)
        
        key_branch = self.key_branches(x)
#        key_branch = self.mpool1(key_branch)
#        print(key_branch.shape)
#        print(key_branch.shape)
        out = (1 + out_branch) * key_branch
#        out_last = self.last_blocks(out)
#        print(out_last.data)
        
        return out

class PAModule_Proj_2(nn.Module):
    # input image size is 14*14
    def __init__(self, in_channels, out_channels, size1=(16,16)):
        super(PAModule_Proj_2, self).__init__()
#        self.conv1 = nn.Conv2d(in_channels, out_channels//2, 1, 1, bias = False)
#        
        self.first_residual_blocks = ResidualBlock(in_channels, out_channels)

        self.value_branches = nn.Sequential( #10
           nn.Conv2d(in_channels, 1,kernel_size=9, stride=2, padding=4, bias = False),
           nn.BatchNorm2d(1),
           nn.ReLU(inplace=True),
#           nn.Conv2d(1, out_channels,kernel_size=3, stride=1, padding=1, bias = False)
         )
        self.value_branches2 =nn.Conv2d(1, out_channels,kernel_size=5, stride=1, padding=2, bias = False)
       
        self.mpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
       

        self.key_branches = nn.Sequential(
#            nn.BatchNorm2d(out_channels),
#            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=4, padding=0, bias=False),
            nn.Sigmoid()
        )

        self.last_blocks = ResidualBlock(in_channels, out_channels) 
 
    def forward(self, x):
#        x = self.first_residual_blocks(x)
#        print(x.shape)
        out_branch = self.value_branches(x)
#        print(out_branch.shape,x.shape)
#        print('drawfeature...')
#        draw_features(8,8, out_branch.detach().cpu().numpy(), "HeatMap/{}.png".format(time.time()-3))
        out_branch=self.value_branches2(out_branch)
        out_branch = self.mpool1(out_branch)
#        print(out_branch.shape,x.shape)
        
        key_branch = self.key_branches(x)
#        key_branch = self.mpool1(key_branch)
#        print(key_branch.shape)
#        print(key_branch.shape,out_branch.shape)
        out = (1 + out_branch) * key_branch
#        out_last = self.last_blocks(out)
#        print(out_last.data)
        
        return out
class PAModule_Proj_3(nn.Module):  #小尺寸卷积核 kernel_size=1, 对第二类有效
    # input image size is 14*14
    def __init__(self, in_channels, out_channels, size1=(16,16)):
        super(PAModule_Proj_3, self).__init__()
#        self.conv1 = nn.Conv2d(in_channels, out_channels//2, 1, 1, bias = False)
#        
        self.first_residual_blocks = ResidualBlock(in_channels, out_channels)

        self.value_branches = nn.Sequential( #10
           nn.Conv2d(in_channels, 1,kernel_size=9, stride=2, padding=4, bias = False),
           nn.BatchNorm2d(1),
           nn.ReLU(inplace=True),
           nn.Conv2d(1, 1,kernel_size=7, stride=1, padding=3, bias = False),
           nn.BatchNorm2d(1),
           nn.ReLU(inplace=True),
#           nn.Conv2d(1, out_channels,kernel_size=3, stride=1, padding=1, bias = False)
         )
        self.value_branches2 =nn.Conv2d(1, out_channels,kernel_size=5, stride=1, padding=2, bias = False)
       
        self.mpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
       

        self.key_branches = nn.Sequential(
#            nn.BatchNorm2d(out_channels),
#            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=4, padding=0, bias=False),
            nn.Sigmoid()
        )

        self.last_blocks = ResidualBlock(in_channels, out_channels) 
 
    def forward(self, x):
#        x = self.first_residual_blocks(x)
#        print(x.shape)
        out_branch = self.value_branches(x)
#        print(out_branch.shape,x.shape)
#        print('drawfeature...')
#        draw_features(8,8, out_branch.detach().cpu().numpy(), "HeatMap/{}.png".format(time.time()-3))
        out_branch=self.value_branches2(out_branch)
        out_branch = self.mpool1(out_branch)
#        print(out_branch.shape,x.shape)
        
        key_branch = self.key_branches(x)
#        key_branch = self.mpool1(key_branch)
#        print(key_branch.shape)
#        print(key_branch.shape,out_branch.shape)
        out = (1 + out_branch) * key_branch
#        out_last = self.last_blocks(out)
#        print(out_last.data)
        
        return out
  
 
class PAModule_Proj_4(nn.Module): #大尺寸卷积核对第三类有效 kernel_size=19,
    # input image size is 14*14
    def __init__(self, in_channels, out_channels):
        super(PAModule_Proj_4, self).__init__()
#        self.conv1 = nn.Conv2d(in_channels, out_channels//2, 1, 1, bias = False)
#        
        self.first_residual_blocks = ResidualBlock(in_channels, out_channels)

        self.value_branches = nn.Sequential( #10
           nn.Conv2d(in_channels, 1,kernel_size=9, stride=2, padding=4, bias = False),
           nn.BatchNorm2d(1),
           nn.ReLU(inplace=True),
           nn.Conv2d(1, 1,kernel_size=7, stride=1, padding=3, bias = False),
           nn.BatchNorm2d(1),
           nn.ReLU(inplace=True),
#           nn.Conv2d(1, out_channels,kernel_size=3, stride=1, padding=1, bias = False)
         )
        self.value_branches2 =nn.Conv2d(1, out_channels,kernel_size=5, stride=1, padding=2, bias = False)
       
        self.mpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
       

        self.key_branches = nn.Sequential(
#            nn.BatchNorm2d(out_channels),
#            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=1, stride=4, padding=0, bias=False),
            nn.Sigmoid()
        )

        self.last_blocks = ResidualBlock(in_channels, out_channels) 
 
    def forward(self, x):
#        x = self.first_residual_blocks(x)
#        print(x.shape)
        out_branch = self.value_branches(x)
#        print(out_branch.shape,x.shape)
#        print('drawfeature...')
#        draw_features(8,8, out_branch.detach().cpu().numpy(), "HeatMap/{}.png".format(time.time()-3))
        out_branch=self.value_branches2(out_branch)
        out_branch = self.mpool1(out_branch)
#        print(out_branch.shape,x.shape)
        
        key_branch = self.key_branches(x)
#        key_branch = self.mpool1(key_branch)
#        print(key_branch.shape)
#        print(key_branch.shape,out_branch.shape)
        out = (1 + out_branch) * key_branch
#        out_last = self.last_blocks(out)
#        print(out_last.data)
        
        return out
